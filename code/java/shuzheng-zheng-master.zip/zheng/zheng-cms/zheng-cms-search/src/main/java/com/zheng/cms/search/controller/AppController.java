package com.zheng.cms.search.controller;

/**
 * 控制器基类
 * @author shuzheng
 * @date 2016年7月7日 上午10:08:47
 */
public class AppController {
	


}