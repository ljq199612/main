package com.zheng.cms.common.constant;

import com.zheng.common.base.BaseConstants;

/**
 * cms系统常量类
 * Created by shuzheng on 2017/2/19.
 */
public class CmsConstant extends BaseConstants {

}
