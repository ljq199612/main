# zheng-message

实时通知系统

## 技术选型

后端：https://github.com/mrniko/netty-socketio

前端：https://socket.io/

